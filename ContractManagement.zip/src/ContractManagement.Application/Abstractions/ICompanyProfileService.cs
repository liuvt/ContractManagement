﻿using ContractManagement.Application.Admins.CompanyProfiles;

namespace ContractManagement.Application.Abstractions;

public interface ICompanyProfileService
{
    Task<IReadOnlyList<CompanyProfileOptionDto>> GetActiveOptionsAsync(
        CancellationToken cancellationToken = default);
}