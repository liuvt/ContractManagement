﻿using ContractManagement.Application.Abstractions;
using ContractManagement.Application.Admins.CompanyProfiles;
using ContractManagement.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ContractManagement.Infrastructure.Services;

public sealed class CompanyProfileService(
    IDbContextFactory<ApplicationDbContext> dbFactory)
    : ICompanyProfileService
{
    public async Task<IReadOnlyList<CompanyProfileOptionDto>>
        GetActiveOptionsAsync(
            CancellationToken cancellationToken = default)
    {
        await using var db =
            await dbFactory.CreateDbContextAsync(cancellationToken);

        return await db.CompanyProfiles
            .AsNoTracking()
            .Where(x => x.IsActive)
            .OrderByDescending(x => x.IsDefault)
            .ThenBy(x => x.CompanyName)
            .Select(x => new CompanyProfileOptionDto
            {
                Id = x.Id,
                CompanyName = x.CompanyName,
                TaxCode = x.TaxCode,
                IsDefault = x.IsDefault
            })
            .ToListAsync(cancellationToken);
    }
}